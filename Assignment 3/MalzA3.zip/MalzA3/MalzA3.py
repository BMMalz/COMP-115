"""
==========================================================
Programmer:  Benjamin Malz
Summary:     This program calculates the slopes and distances between points
given in a .csv file, the portion of the screen that the user is looking at,
prints them and then finishes by displaying the average and total distance.


INPUT (keyboard, stdin):  The program prompts the users to input the filename
of the .csv the user has their values stored on.
        
        
INPUT (from a file of data):  The .csv file has two columns of values which
the program reads and assigns variables to in order to compute the distance,
slope and location the values would represent in the eye tracking goggles.
     
        
OUTPUT (console, stdout): Prints the two points, the distance and slope between
these points and the position the eye goggle user is looking at on the screen.
The program then moves onto the next point and repeats until there are no more
points. The program then prints the average and total distance.

Date Last Modified:
 08/12/2016:  (mdl) Starter Kit created
 09/13/2016:  (mdl) now handling many (x,y) points
 10/01/2016: Implemented all code inside of the for loop.
 10/03/2016: Added the avgDist and totalDist variables to print at the end of
 the program, beautified program and added printTitle()
========================================================== 
"""

import math
import sys

# ======================================================
# def distance
def distance(x1,y1,x2,y2):
    
    dist = math.sqrt((x2 - x1)**2 + (y2 - y1)**2)
    
    return dist
# ======== end distance() ==============================

# ======================================================
# def slope
def slope( x1, y1, x2, y2 ):
    slope = 0
    if ((x2 - x1) != 0):
        slope = (y2 - y1)/(x2 - x1)
    else:
        print("No slope.")
    
    
    return slope
# ======== end slope() =================================

# ======================================================
#def printTitle
def printTitle():
    print("-------------------------------------------")
    print("---------Gaze Fixation Information---------")
    print("------All numbers in units of pixels-------")
    print("-------------------------------------------")
# ======== end printTitle() ============================
#def printDirect
def printDirect(x2, y2):
    if (x2 <= 50) and ( y2 <= 25):
        print("Looking down and to the left.")
    elif (x2 <= 50) and (y2 >= 26):
        print("Looking up and to the left.")
    elif (x2 >= 51) and (y2 <= 25):
        print("Looking down and to the right.")
    elif (x2 >= 51) and (y2 >= 26):
        print("Looking up and to the right.")
    elif (x2 == 50) and (y2 == 25):
        print("Looking directly in the middle.")
#======== end printDirect() ============================

# ======================================================
#def printSlope
def printSlope(x1,y1,x2,y2):
    print("The slope of", x1,",", y1, "and", x2,",", y2,"is: %5.2f" % slope(x1,y1,x2,y2))
# ======== end printSlope() ============================


def main():
    
    
    # ask user to enter the filename containing eye-tracking points
    fileName = input("Enter filename: ")
    # or
    # manually assign filename for testing purposes
    printTitle()
    #fileName = "eyetracking1.csv"
    
    FILE = open(fileName, 'r')
    print ("Using data file: ", fileName, "\n")
    
    # handle the first line of column headers
    headerLine = FILE.readline()
    headerLine = headerLine.strip()
    xHeader, yHeader = headerLine.split(",")    
    
    # grab initial (x,y) gaze point; we are assuming at least one (x,y) is in the file
    firstLine = FILE.readline()
    firstLine = firstLine.strip()
    x1,y1 = firstLine.split(",")
    x1 = float(x1)
    y1 = float(y1)
    
    point = 1  # keep track of which (x,y) pair we are processing
    print("Gaze Fixation (",point,"):%5.1f " % x1,",%5.1f" % y1)
    print("Coordinates:(%5.1f,%5.1f)" % (x1, y1))
    printDirect(x1,y1)
    totalDist = 0
    # process each line in the file, one line at a time
    for nextLine in FILE:
    
        nextLine = nextLine.strip()
        
        x2,y2 = nextLine.split(",")
        x2 = float(x2)
        y2 = float(y2)
        """
        # FYI: a Pythonesque way to split and cast to float
        (x2,y2) = [float(x) for x in nextLine.split(",") ]
        """
        print ("-"*35)
        point = point + 1
        print("Point number", point)
        print("Gaze Fixation (",point - 1,"): %5.1f" % x1, ", %5.1f" % y1)
        print("Gaze Fixation (",point,"):",nextLine)
        distance(x1,y1,x2,y2)
        print("Distance between %5.1f" % x1,", %5.1f" % y1,"and %5.1f" % x2,",%5.1f" % y2,"is:%6.2f" % distance(x1,y1,x2,y2))
        printSlope(x1,y1,x2,y2)
        printDirect(x2,y2)
        totalDist = (totalDist + distance(x1,y1,x2,y2))      
        x1 = x2
        y1 = y2
        

    
        
    # end for each line of (x,y) data
    
    
    avgDist = totalDist/point
    print ("-"*55)
    print("The total Gaze Distance between points (1) and (", point,")", "is: %5.2f" % totalDist)
    print("The average distance between Gaze Fixations is: %7.2e" % avgDist)
    
    print ("\nDone.")
    
# ======== end main() =================================
    
    

# program STARTS HERE ...
#-----------------------------------------------------
if __name__ == '__main__':
    main()
#-----------------------------------------------------    