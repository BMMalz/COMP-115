
#============================================================================
# Code guy: Benjamin Malz

# Summary: This program reads a text file and then counts the total syllables,
#total words, total sentences and then calculates the Flesch Reading Ease and
#Flesch Grade Level, then puts them in a .csv file

# INPUT: User types in a text filename - the program reads it. If it isn't
#an existing file the user must restart the program.

# OUTPUT: The program calculates the total words, syllables, sentences, reading
#ease, grade level and the top 10 most used words and stores them in a .csv file.

# Date Last Modified:
#  (mdl) 11/11/2016 -- set up starting kit
#  (BMM) 12/01/2016 -- reads file, converts to string, removes punctuation, lowercases
#  (BMM) 12/02/2016 -- added word and sentence counter, word list
#  (BMM) 12/05/2016 -- added dictionary, sorted dictionary and syllable counter
#  (BMM) 12/06/2016 -- added reading ease and grade level, top 10 words,
#writes all information to .csv file

# My EXTENDED definition of READING LEVEL: The reading ease is the difficulty
#of a text in the form of a number. The lower it is, the harder it is to read.
#The grade level is a formula that calculates the difficulty of a text to read
#and converts it to a U.S. grade school level. The higher the number, the harder
#it is to read.

#============================================================================

import string
import os
import re

# import the funcitons in the readingLevel.py module
from readingLevel import *
    


#--------\
# main()  \
#-------------------------------------------
def main():
    
	fileAsString = getData()
	noPunct = remove_punctuation(fileAsString)
	
	totalWords     = getNumberOfTotalWords(noPunct)
	totalSentences = getNumberOfTotalSentences(fileAsString)
	# dump values to the console (just for debugging purposes)
	print ("total words:      ", totalWords)
	print ("total sentences : ", totalSentences)
	totalSyllables = getNumberOfTotalSyllables(fileAsString)
	print ("\ntotal syllables:     ", totalSyllables)
	
	
	readingEase = compute_FleschReadingEase( totalSyllables, totalWords, totalSentences)
	print ("\nReading Ease:    %5.2f" % readingEase)
		
	readingLevel = compute_FleschKincaidGradeLevel( totalSyllables, totalWords, totalSentences)
	print ("Grade Level:     %5.2f" % readingLevel)

		
	printReadingLevelReport(totalSyllables, totalWords, totalSentences, readingEase, readingLevel)
	
	printTopNwords(fileAsString, TOP_N_WORDS)
	
	
# end main()





#-----------\
# START HERE \
#-----------------------------------------------------------	
if (__name__ == '__main__'):
	
	# CONSTANTS
	SENTENCE_MARKER = "XXX"
	
	TOP_N_WORDS = 10
	
	main()
	
	print ("\n\nDone.\n")

#-----------------------------------------------------
