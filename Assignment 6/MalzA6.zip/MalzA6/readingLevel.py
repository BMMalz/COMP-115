import os
import string

# module readingLevel.py



#----------------------\
# remove_punctuation()  \
#-----------------------------------------------------------
# This function accepts one string (s) and removes all
# the punctuation symbols found in the string module's
# string.punctuation
# IN:  one string (e.g., a sentence or entire story)
# RETURNS: that same string but with all punctuation gone
#-----------------------------------------------------------
def remove_punctuation(s):
	"""remove punctuation from string, s"""
	s_without_punct = ""
	for letter in s:
		if letter not in string.punctuation:
			s_without_punct += letter
			
	return s_without_punct

# end remove_punctuation()



#-----------\
# getData()  \
#-----------------------------------------------------------
# Prompts user for filename, opens the file, converts it into a string and replaces
# all sentence endings with "XXX" what to strip for future use and how many sentences
# there are in total.
#-----------------------------------------------------------
def getData():
	"""open file, read all lines, return as one string"""
	textString = "" #the empty string to store all the text in later
	theFileName = input("\nEnter filename: ") #opens file
	if not os.path.exists(theFileName):
		print("File not found!") #if the file doesn't exist, tells user
	else:
		print("Reading from file:", theFileName) #informs user what file is being read
		FILE = open(theFileName, 'r') #open file, read
		for nextLine in FILE:
			nextLine = nextLine.strip() #strips newline character
			textString = textString + nextLine + " " #adds spaces between words,
			#adds new words to textString
		textString = textString.lower() #lowercases textString so different
		#capitalizations don't confuse program later
		textString = textString.replace('.', 'XXX') #gives all 3 sentence
		#endings a consistent marker
		textString = textString.replace('!', 'XXX')
		textString = textString.replace('?', 'XXX')
		#print(textString)
		#returns textString now that it's in the condition needed
		return textString 
	
# end getData()


#--------------------\
# syllablesPerWord()  \
#-----------------------------------------------------------
# Counts how many syllables there are in a word, avoids tricky situations like
# a silent e or a diphthong
#-----------------------------------------------------------
def syllablesPerWord( word ):
	""" you do this """
	#(1) Count the number of vowels (‘a’, ‘e’, ‘i’, ‘o’, ‘u’, and sometimes ‘y’) in the word.
	#(2) Subtract any silent vowels (like the silent ‘e’ at the end of a word).
	#(3) Subtract 1 vowel from every diphthong. 
	#    A diphthong is when two vowels make only 1 sound:
	#              (oi, oy, ou, ow, au, aw, oo, ie, ea, ee, ai).
	
	diphthongList = ["oi", "oy", "ou", "ow", "ai", "au", "ay", "aw", "oo", "ie", "ea", "ee"]
	vowelList = ["a", "e", "i", "o", "u", "y"]
	i = 0 #keep track of position in a word
	sylCount = 0 #keep track of how many syllables there are
	while (i < (len(word))): #ensures i doesn't keep counting beyond word's length
		if (i == 0) and (word[i] in vowelList):
			i += 1
		elif (i == 0) and (word[i] not in vowelList):
			i += 1 #these 2 if statements just prevent confusion
			#when moving beyond the first letter
		elif (word[i] in vowelList) and (word[i-1:i+1] not in diphthongList):
			sylCount += 1
			i += 1
			#if the letter is a vowel but is NOT a diphthong when combined
			#with the previous letter, the syllable count should increase
		elif (word[i] in vowelList) and (word[i-1:i+1] in diphthongList):
			sylCount -= 1
			i += 1
			#ensures that a diphthong is NOT counted as two syllables
			#even though it is 2 vowels
		elif (i == len(word) - 1) and (word[i-2:i] == "le"):
			sylCount += 1
			i += 1
			#words that end with "le" should count as an additional
			#syllable, despite ending with e
		elif (i == len(word) - 1) and (word[i-2:i] == "ed"):
			i += 1	
			#even though there's an "e", words ending with "ed"
			#should not increase in syllable count despite the vowel
		elif (i == len(word) - 1) and (word[i-1:i] == "e"):
			i += 1
			sylCount -= 1
			#subtracts 1 from syllable count if last letter is silent "e"
			#otherwise it counts the "e" before seeing this if statement
			#and then is not corrected
		else:
			i += 1
			
	
	if (sylCount == 0): #if the count is 0 it's safe to assume the word is 1 syllable
		return 1
	else:
		return sylCount
			
	#return (sylCount)
		
# syllablesPerWord()


#-------------------------\
# getNumberOfTotalWords()  \
#-------------------------------------------
# This counts the number of words in a given text.
#-------------------------------------------
def getNumberOfTotalWords( s ):
	i = 0 #tracks position in the string
	wordCount = 0 #creates variable that tracks word
	while (i < len(s) - 1): #so that it keeps going through string until i equals length
		if ((i)==len(s)): 
			#returns wordCount because it finished counting if i equals length
			return wordCount 
		elif (s[i+1] == " "):
			i += 1 #if the program detects a space it must determine that there
			#are no extra spaces to count as words
			if ((i + 1) >= len(s)):
				#prevents program from overcounting and crashing
				return wordCount
			elif (s[i+1] != " "):
				#if the character after the space isn't a space,
				#increase wordCount
				wordCount += 1
				i += 1
				#print(wordCount)
			elif (s[i+1] == " "):
				i += 1
				#if character after space IS a space then don't
				#consider it another word
		else:
			i += 1
	
	return wordCount


#-----------------------------\
# getNumberOfTotalSentences()  \
#-------------------------------------------
# Counts the number of sentences in the given text.
#-------------------------------------------
def getNumberOfTotalSentences( s ):
	i = 0 #track position in string
	sentenceCount = 0 #track number of sentences
	while (i < len(s)): #keeps the program from counting sentences that don't exist	
		if (s[i:i + 3] == "XXX"):
			#the sentence marker is "XXX" so if it finds it then there must
			#be a new sentence starting
			sentenceCount += 1
			i += 1
		else:
			i += 1
	return sentenceCount
#-----------------------------\
# getNumberOfTotalSyllables()  \
#-------------------------------------------
# Sends each word to be counted for syllables individually.
#-------------------------------------------
def getNumberOfTotalSyllables( s ):
	totalSyl = 0 #keeps count of the total syllables
	noPunctString = remove_punctuation(s) #makes sure there's no punctuation
	noPunctString = noPunctString.split() #without the .split() it splits
	#on individual letters which is useless
	for nextWord in noPunctString:
		nextWord = nextWord.strip("XXX") #no need for sentence markers here
		totalSyl += syllablesPerWord(nextWord) #adds new syllable count
		#to current count
	#print(totalSyl) #for testing
		
	
	
	
	
	
	return totalSyl
    
# end getNumberOfTotalSyllables()


#-----------------------------\
# compute_FleschReadingEase()  \
#-------------------------------------------
# Calculates the ridiculously long formula for Flesch Reading Ease after
# being sent all needed variables
#-------------------------------------------
def compute_FleschReadingEase(totalSyllables, totalWords, totalSentences):
	readingEase = 0 #creates variable
	readingEase = (206.835 - (1.015 * ((totalWords)/(totalSentences))) - (84.6 * ((totalSyllables)/(totalWords))))
	#stores answer to formula

	return readingEase
	
	
#-----------------------------------\
# compute_FleschKincaidGradeLevel()  \
#-------------------------------------------
# Calculates the Flesch-Kincaid Grade Level with the given variables
#-------------------------------------------
def compute_FleschKincaidGradeLevel(totalSyllables, totalWords, totalSentences): 
	gradeLevel = 0 #creates variable
	gradeLevel = (0.39 * ((totalWords)/(totalSentences)) + (11.8 * ((totalSyllables)/(totalWords))) - 15.59)
	#stores answer to formula
	return gradeLevel

#---------------------------\
# printReadingLevelReport()  \
#-------------------------------------------
# Writes all the data calculated throughout this program into a .csv file
#-------------------------------------------
def printReadingLevelReport(totalSyllables, totalWords, totalSentences, readingEase, readingLevel): 
	CSV = open("report.csv", "w") #opens a new CSV file, "report.csv"
	#creates the header line for each column of the CSV
	header = "Syllables, Words, Sentences, Reading Ease, Reading Level"
	#turns the variables into strings so they can be combined with commas
	totalSyllables = str(totalSyllables)
	totalWords = str(totalWords)
	totalSentences = str(totalSentences)
	readingEase = str(readingEase)
	readingLevel = str(readingLevel)
	#makes a CSV-friendly data line
	data = (totalSyllables + "," + totalWords + "," + totalSentences + "," + readingEase + "," + readingLevel)
	CSV.write(header + "\n") #writes header lines, makes sure to start next line
	CSV.write(data + "\n") #writes data on next line in .csv, starts next line
	
	
	
	
	
	CSV.close() #don't need the file anymore
	


	
#------------------\
# printTopNwords()  \
#-------------------------------------------	
def printTopNwords(s, N): 
	allWords = [] #creates list to store words into
	allWordsNum = {} #creates dictionary to store words into with values
	noPunctString = remove_punctuation(s) #remove punctuation to avoid confusion
	noPunctString = noPunctString.split() #prevent string being split by letter
	for nextLine in noPunctString:
		nextLine = nextLine.strip("XXX") #don't need sentence marker
		allWords.append(nextLine) #adds word to list
	#print(allWords)
	for nextWord in allWords:
		if (nextWord in allWordsNum.keys()):
			# if the word is already in dictionary, add to value
			allWordsNum[nextWord] = allWordsNum[nextWord] + 1
		else:
			allWordsNum[nextWord] = 1
			#if not in dictionary then put it in new key
	sortedWordsNum = {} #new dictionary sorted by value
	for (word,count) in allWordsNum.items():
		if count in sortedWordsNum:
			sortedWordsNum[count].append(word)
		else:
			#new list with just this word
			sortedWordsNum[count] = [word]
	#print(sortedWordsNum)
	N = 10
	CSV = open("report.csv", "a") #opens the report to add top 10 words
	for (key, val) in sorted(sortedWordsNum.items(), reverse=True):
			if (N > 0):
				print (key, val)
				#prints top 10 words in console
				#converts to strings to write to .csv
				csvKey = str(key)
				csvVal = str(val)
				csvStr = (csvKey + "," + csvVal)
				CSV.write(csvStr + "\n")
				N -= 1	
	
	
		

	#CSV = open("report.csv", "a")
	
	# remove punctuation before counting words, so King's and King are same	
	
	#CSV.write()
	
	CSV.close()
